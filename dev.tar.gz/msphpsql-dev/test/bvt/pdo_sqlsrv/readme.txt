This folder mainly contains tests that are derived from the code examples on 

https://docs.microsoft.com/en-us/sql/connect/php/pdo-class
https://docs.microsoft.com/en-us/sql/connect/php/pdostatement-class

Modify connect.inc with the real credentials to run the tests, using the latest run-tests.php from 
https://raw.githubusercontent.com/php/php-src/master/run-tests.php