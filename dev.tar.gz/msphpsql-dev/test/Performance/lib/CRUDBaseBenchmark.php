<?php

/**
 * @Iterations(1000)
 */
abstract class CRUDBaseBenchmark
{
}
?>