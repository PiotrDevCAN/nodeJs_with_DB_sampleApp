<?php
$server = 'server';
$database = 'testdb';
$uid = 'usr';
$pwd = 'pwd';
$pooling=false;
$mars=false;
?>
