<?php
$server = 'server';
$database = 'testdb';
$uid = 'usr';
$pwd = 'pwd';
?>
